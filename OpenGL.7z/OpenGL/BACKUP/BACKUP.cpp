#include "GL/glew.h"
#include <math.h>
#define PI 3.1416
#define ToRadian(x) ((x) * PI / 180.0f)
#define ToDegree(x) ((x) * 180.0f / PI)
#define GLFW_DLL
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp" 
#include "glm/gtc/type_ptr.hpp" 
#include "GLFW/glfw3.h"
#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include "Shader.h"
#include "Vao.h"
#include "Window.h"
#include "Camera.h"

GLuint gTransformationLocation;
GLuint gProjectionLocation;
GLuint gViewLocation; 	
GLfloat Traslation = 0;



GLfloat coordenates[] = {
       -1.0f, -1.0f, 0.0f,
        0.0f, -0.5f, 1.0f,
        1.0f, -1.0f, 0.0f,
        0.0f,  1.0f, 0.0f
    }; 

GLuint index[] = {0,3,1,
									1,3,2,
									2,3,0,
									0,1,2,};

const char *vertex_shader =
"#version 410\n"
"layout(location = 0) in vec3 vp;"
"uniform mat4 gTransformation;"
"uniform mat4 gProjection;"
"uniform mat4 gViewMatrix;"
"out vec4 Color;"
"void main() {"
"gl_Position = gProjection * gViewMatrix * gTransformation * vec4(vp, 1.0);"
"Color = vec4(clamp(vp, 0.0, 1.0), 1.0);"
"}";

const char *fragment_shader =
"#version 410\n"
"in vec4 Color;"
"out vec4 frag_colour;"
"void main() {"
"frag_colour = Color;"
"}";

Window newWindow;
shader newShader(vertex_shader, fragment_shader);

glm::mat4 createTransformationMatrix(glm::vec3 translation, float rx, float ry,
    float rz, float scale)
{
    glm::mat4 matrix;
    matrix = glm::translate(matrix, translation);
    matrix = glm::rotate(matrix,glm::radians(rx), glm::vec3(1.0, 0.0, 0.0));
    matrix = glm::rotate(matrix,glm::radians(ry), glm::vec3(0.0, 1.0, 0.0));
    matrix = glm::rotate(matrix,glm::radians(rz), glm::vec3(0.0, 0.0, 1.0));
    matrix = glm::scale(matrix, glm::vec3(scale , scale , scale));
    return matrix;
} 

glm::mat4 createProjectionMatrix(float fov, float width, float height){
	glm::mat4 projectionMatrix;
	projectionMatrix = glm::perspective(fov, width / height, 0.1f, 1000.0f);
	std::cout << "FOV: " << fov << std::endl;
	return projectionMatrix;	
}

glm::mat4 createViewMatrix(Camera camera, float pitch, float yaw){
	glm::mat4 viewMatrix;
	camera.setPitch(pitch);
	camera.setYaw(yaw);
	viewMatrix = glm::rotate(viewMatrix,glm::radians(camera.getPitch()), glm::vec3(1.0,0.0,0.0));
	viewMatrix = glm::rotate(viewMatrix,glm::radians(camera.getYaw()), glm::vec3(0.0,1.0,0.0));
	glm::vec3 cameraPos = camera.getPosition();
	glm::vec3 negCameraPos = glm::vec3(-cameraPos.x, -cameraPos.y, -cameraPos.z);
	viewMatrix = glm::translate(viewMatrix, negCameraPos);
	std::cout << "Camera Pos: " << cameraPos.x <<" "<< cameraPos.y <<" "<< cameraPos.z <<std::endl;
	return viewMatrix;
}

void renderScene(){
   while(!glfwWindowShouldClose (newWindow.getWindow())) {   	            
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glUseProgram(newShader.getShaderProgramme());
      glBindVertexArray(0);
      
			GLfloat Scale = 360;			
			Scale += 0.001;
			if(Scale >= 360) Scale=0;
			std::cout << "Scale: " << Scale << std::endl;
			
			glm::mat4 modelView = createTransformationMatrix(glm::vec3(0,0,0), 0, 0, 0, 0.1f);
			glm::mat4 viewMatrix = createViewMatrix(Camera(glm::vec3(0,0,1)), 0, 0);
			glm::mat4 projectionMatrix = createProjectionMatrix(90, 512.0f, 512.0f);

      glUniformMatrix4fv(gTransformationLocation, 1, GL_FALSE, glm::value_ptr(modelView));
      glUniformMatrix4fv(gProjectionLocation, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
      glUniformMatrix4fv(gViewLocation, 1, GL_FALSE, glm::value_ptr(viewMatrix));
      
      glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, 0);
      glfwPollEvents();
      glfwSwapBuffers(newWindow.getWindow());      
  }
}
			
void KeyCallback(GLFWwindow* pWindow, int key, int scancode, int action, int mods)
{   
    if (key == GLFW_KEY_E && action == GLFW_PRESS)
        std::cout << "Key E pressed" << std::endl;
}			
int main()
{   
	
	 MainGame game;
	 game.run();

   Vao newVao(coordenates, index ,sizeof(coordenates), sizeof(index));

   
   gTransformationLocation = glGetUniformLocation(newShader.getShaderProgramme(), "gTransformation");
   gProjectionLocation = glGetUniformLocation(newShader.getShaderProgramme(), "gProjection");
   gViewLocation = glGetUniformLocation(newShader.getShaderProgramme(), "gViewMatrix"); 	
   
   //renderScene();
      
     while(!glfwWindowShouldClose (newWindow.getWindow())) {   	            
      
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      glBindVertexArray(newVao.getId());
      
			GLfloat Scale = 360;			
			Scale += 0.001;
			if(Scale >= 360) Scale=0;
			std::cout << "Scale: " << Scale << std::endl;
			
			glm::mat4 modelView = createTransformationMatrix(glm::vec3(0,0,0), 0, 0, 0, 0.1f);
			glm::mat4 viewMatrix = createViewMatrix(Camera(glm::vec3(0,0,1)), 0, 0);
			glm::mat4 projectionMatrix = createProjectionMatrix(90, 512.0f, 512.0f);

      glUniformMatrix4fv(gTransformationLocation, 1, GL_FALSE, glm::value_ptr(modelView));
      glUniformMatrix4fv(gProjectionLocation, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
      glUniformMatrix4fv(gViewLocation, 1, GL_FALSE, glm::value_ptr(viewMatrix));
      
      glfwSetKeyCallback(newWindow.getWindow(), KeyCallback);
      
      glDrawElements(GL_TRIANGLES, 12, GL_UNSIGNED_INT, 0);
      glfwPollEvents();
      glfwSwapBuffers(newWindow.getWindow());      
  }
      
   glfwTerminate();
   return 0;
    
}