#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node
{
	char data;
	struct node *next;
};

typedef struct node node;
typedef unsigned char bool;

char c[] = "otoj_se_erriugA";

void initList(node **l)
{
	*l = NULL;
}

void insert_list(node **head, int d)
{
	node *tmp = (node *) malloc(sizeof(node));
	tmp->data = d;
	tmp->next = *head;
	*head = tmp;
}

void create_cycle(node **last, node *toPoint)
{
	printf("Elemen from %d to %d \n", (*last)->data, toPoint->data);
	(*last)->next = toPoint;
}

void print_list(node *head)
{
	node *l;
	printf("\n=============Printing list=============\n");
	for(l = head; l != NULL; l = l->next)
		printf("%c->", l->data);
	printf("NULL\n");
	printf("\n=======================================\n");
}

node *get_end(node *l)
{
	node *end;
	for(end = l; end->next != NULL; end = end->next);

	return end;
}

bool has_cycle(node *head)
{
	node *slow;
	node *fast;

	slow = fast = head;

	while(fast != NULL && fast->next != NULL)
	{
		slow = slow->next;
		fast = fast->next->next;

		if(slow == fast)
			return 1;
	}

	return 0;
}

int main()
{
	int i;
	node *l;
	node *cycle;
	node *last;


	initList(&l);

	for(i = 0; i < strlen(c); ++i)
		insert_list(&l,c[i]);
	/*for(i = 0; i < 10; ++i)
		insert_list(&l, i);*/

	print_list(l);

	printf("\nChecking if list has a cycle\n");
	if(has_cycle(l))
		printf("list has a cycle\n");
	else
		printf("List doest not has a cycle\n");

	printf("\nAdding a cycle\n");
	cycle = l;
	for(i = 0; i < 5; ++i)
		cycle = cycle->next;

	last = get_end(l);
	create_cycle(&last, cycle);

	printf("Checking if list has a cycle\n");
	if(has_cycle(l))
		printf("list has a cycle\n");
	else
		printf("list doest not has a cycle\n");

	return 0;
}
