#pragma once
#include "GL/glew.h"

struct GLTexture{
	GLuint id;
	int width;
	int height;
};