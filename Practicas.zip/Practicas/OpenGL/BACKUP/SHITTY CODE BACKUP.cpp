#include "GL/glew.h"
#define GLFW_DLL
#include "GLFW/glfw3.h"
#include <stdio.h>
#include <iostream>
#include <string>
#include <vector>
#include "Shader.h"
#include "Vao.h"

const char *vertex_shader =
"#version 410\n"
"in vec3 vp;"
"uniform mat4 traslation;"
"void main() {"
"   gl_Position = traslation * vec4(vp, 1.0);"
"}";

const char *fragment_shader =
"#version 410\n"
"out vec4 frag_colour;"
"void main() {"
"   frag_colour = vec4(1.0, 0.0, 0.5, 1.0);"
"}";

void TraslateMatrix(GLfloat *matrix, size_t size, GLfloat x, GLfloat y){
	std::cout << matrix << std::endl;
	std::cout << "Matrix size: " << size << std::endl;
	for(int i=0; i<size;i+=3){
		*(matrix + i) = *(matrix + i) + x;
	}
	
	for(int i=1; i<size;i+=3){
		*(matrix + i) = *(matrix + i) + y;
	}
}

GLfloat coordenates[] = {
       -0.5f,  0.5f, 0.0f,
       -0.5f, -0.5f, 0.0f,
        0.5f, -0.5f, 0.0f,
        0.5f,  0.5f, 0.0f
};

GLfloat traslationMatrix[] = {
	1.0, 0.0, 0.0, 0.0, // 1 col
	0.0, 1.0, 0.0, 0.0, // 2 col
	0.0, 0.0, 1.0, 0.0, // 3 col
	0.5, 0.0, 0.0, 1.0 // 4 col
};

GLuint index[] = {0,1,2,2,3,0};

GLFWwindow *Initialization(){
    if(!glfwInit()) {
        fprintf (stderr, "ERROR: could not start GLFW2\n");
        //exit(1);
    }


    GLFWwindow *window = glfwCreateWindow(1024,1024,"Hello Triangles", NULL, NULL);
    if(!window)
    {
        fprintf(stderr, "ERROR: could not open window with GLFW3\n");
        glfwTerminate();
        //exit(1);
    } 

    glfwMakeContextCurrent(window);

    glewExperimental= GL_TRUE;
    glewInit();

    const GLubyte *renderer = glGetString(GL_RENDERER);
    const GLubyte *version = glGetString(GL_VERSION);

    printf("Renderer: %s\n", renderer);
    printf("OpenGL version supported %s\n", version);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glClearColor(0.0f, 0.0f, 1.0f, 1.0f); // sizeof(ARRAY)/sizeof(ARRAY[0])

    return window;

}

int main()
{
   GLFWwindow *window = Initialization();

   //TraslateMatrix(coordenates, sizeof(coordenates)/sizeof(coordenates[0]), -0.467787, 0.5678);

   Vao newVao(coordenates, index, sizeof(coordenates), sizeof(index));
   
   shader newShader;
   newShader.init(vertex_shader, fragment_shader);
   newShader.setShaderProgramme();
   newShader.attachShader();
   GLuint location_traslation = glGetUniformLocation(newShader.getShaderProgramme(), "traslation");
   glUniformMatrix4fv(location_traslation,1, GL_FALSE, traslationMatrix);
   std::cout << "Location: " << location_traslation;
	float sergioBecameGay = 0.0;
	float increment = 0.001;
    while(!glfwWindowShouldClose (window)) {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glUseProgram(newShader.getShaderProgramme());
        glBindVertexArray(newVao.getId());
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glfwPollEvents();
        glfwSwapBuffers(window);
    }

    glfwTerminate();

    return 0;
}

