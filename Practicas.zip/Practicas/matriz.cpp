#include <stdio.h>
#include <stdlib.h>

int main()
{
	int **p;
	int i,j;

	int count = 1;
	p = (int **) malloc(5 * sizeof(int));

	for(i = 0; i < 5; i++)
		p[i] = (int *) malloc(5 * sizeof(int));

	while(i--)
	{
		int x, y;
		for(j =0; j < 5; ++j){
			scanf("%d %d", &x, &y);
			p[y][x] = count++;
		}
	}

	return 0;
}
