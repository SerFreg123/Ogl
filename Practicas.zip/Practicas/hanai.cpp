#include <iostream>
#include <stack>

char letter[3] = {'A', 'B', 'C'};
struct hanoi
{
	int disco;
	char draw;
	int nivel;
	hanoi(int l, char d): disco(l), draw(d) { }
};

int getMaxSize(const std::stack<hanoi> tower[], int size)
{
	int max = 0;
	std::stack<hanoi> A[size];
	for(int i =0; i < size; ++i)
		A[i] = tower[i];

	for(int i = 0; i < size; ++i) {
		if(!A[i].empty())
		{
			while(!A[i].empty())
			{
				if(A[i].top().nivel > max)
					max = A[i].top().nivel;
				A[i].pop();
			}
		}
	}

	return max;
}
void printTower( const std::stack<hanoi> tower[], int width, int height)
{
	std::stack<hanoi> A[height];
	for(int i =0; i < height; ++i)
		A[i] = tower[i];
	int count = 0;
	int nivel = 0;
	std::cout<<"Max element "<< getMaxSize(tower, height) << std::endl;
	int maxsize = getMaxSize(tower, height);
	for(int x = maxsize; x>= 0 ; --x)
	{
		for(int a = 0; a < height ; ++a)
		{
			if(!A[a].empty() && A[a].top().nivel == x)
			{
				for(int i = 0; i < width - (maxsize - x); ++i)
					std::cout<< " ";
				for(int j = 0; j < 2*( A[a].top().disco) - 1; ++j)
					std::cout << A[a].top().draw;
				for(int i = 0; i < width -(maxsize - x); ++i)
					std::cout<<" ";

				A[a].pop();
			}
			else
			{
				for(int i = 0; i < (2 * (width)) - 1; ++i)
					std::cout<<" ";
			}
		}
		std::cout << std::endl;
	}
}
void SolveTower(std::stack<hanoi> A[], const int &size)
{
	while(A[1].size() != 5)
	{
		for(int i = 0; i < size; ++i)
		{
			for(int j = (i + 1) % size; j != i; j =  (j + 1) % 3)
			{
				if(i == j)
					continue;

				std::cout << "Indice i = "<< i << std::endl;
				if(!A[i].empty())
				{
					if(A[j].empty())
					{
						std::cout << "Empty "<< std::endl;
						A[j].push(A[i].top());
						std::cout << "< A[" << j << "] = " << A[j].top().disco << std::endl;
						A[j].top().draw = letter[j];
						A[j].top().nivel = 0;
					}
					else
					{
						if(A[i].top().disco < A[j].top().disco)
						{
							std::cout << "Else "<< std::endl;
							std::cout << "A[" << i << "] = " << A[i].top().disco;;
							std::cout << "< A[" << j << "] = " << A[j].top().disco << std::endl;
							A[i].top().nivel = A[j].top().nivel + 1;
							A[j].push(A[i].top());
							A[j].top().draw = letter[j];
							//A[j].top().nivel = 1 + getMaxSize(A, size) - A[i].top().nivel;
						}
						else
							continue;
					}
					std::cout << "A[" << i << "] = " << A[i].top().disco << " Pop"<< std::endl;
					std::cout << "A[" << j << "] = " << A[j].top().disco << " Push Nivel = "<< A[j].top().nivel << std::endl;
					A[i].pop();
				}
				else
				{

					for(int z = 0; z < size; ++z)
					{
						if(z == i)
							continue;

						if(!A[z].empty())
						{
							std::cout << "--A[" << z << "] = " << A[z].top().disco << "--"<< std::endl;
							A[i].push(A[z].top());
							A[i].top().draw = letter[i];
							A[i].top().nivel = 0;
							A[z].pop();
							break;
						}

					}
				}
			printTower(A,5,3);
		//getchar();
			}
		}
		/*if(A[1].empty())
		{
			A[1].push(A[0].top());
			A[1].top().draw = 'B';
			A[1].top().nivel = getMaxSize(A, size) - A[1].top().nivel;
			A[0].pop();
		}else
		{
			if(A[1].top().disco > A[0].top().disco)
			{
				A[1].push(A[0].top());
				A[1].top().draw = 'B';
				A[1].top().nivel = getMaxSize(A, size) - A[1].top().nivel;
				A[0].pop();
			}
		}*/
		/*if(A[2].empty())
		{
			A[2].push(A[1].top());
			A[2].top().draw = 'C';
			A[2].top().nivel = getMaxSize(A, size) - A[1].top().nivel;
			A[1].pop();
		}else
		{
			if(A[2].top().disco > A[1].top().disco)
			{
				A[2].push(A[1].top());
			}
		}*/

	}
}
std::stack<hanoi> CreateTower(const int &size, char c)
{
	std::stack<hanoi> A;

	std::cout << "Size " << size << std::endl;
	for(int i = size; i > 0 ; --i)
	{
		hanoi tmp(i,c);
		tmp.nivel = size - i;
		std::cout << "Pushing " << tmp.disco << " nivel" << tmp.nivel  << std::endl;
		A.push(tmp);
	}

	std::cout << "A size " << A.size() << std::endl;
	return A;
}
int main()
{
	std::stack<hanoi> A[3];

	/*for(int i =0; i < 3; ++i)
		A[i] = CreateTower(5, i + 65);*/

	A[0] = CreateTower(5,'A');

	std::cout << "Printing "<< std::endl;
	printTower(A, 5, 3);
	SolveTower(A,3);
}




